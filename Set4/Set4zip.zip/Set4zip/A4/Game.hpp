#ifndef GAME_HPP
#define GAME_HPP



#endif

/*
//const float PI = 3.1415926;

class Game {
    private:
        int numPlayers;
        int currPlayer;
        bool direction;
        int numChips;
    public:
        //double volume();
};
*/