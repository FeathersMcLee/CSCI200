#ifndef DIE_HPP
#define DIE_HPP

//const float PI = 3.1415926;

class Die {
    private:
        int value;
    public:
        void keepChip();

};

void Die::keepChip() {
    return;
}

#endif